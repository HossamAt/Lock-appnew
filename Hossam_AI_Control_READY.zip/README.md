# Hossam AI Control

Kill Switch مستقل للنسخة الجديدة من Hossam AI.

## ملف التحكم
`kill_switch.json`

## الرابط الذي يستخدمه التطبيق
https://raw.githubusercontent.com/HossamAt/Hossam-AI-Control/main/kill_switch.json

## التحكم
من GitHub:
Actions → Update Hossam AI Control → Run workflow

- `true` = التطبيق يعمل
- `false` = إيقاف التطبيق
- `message` = الرسالة التي تظهر للمستخدم
- `version` = رقم إصدار التحكم

مهم: لا تستخدم هذا الريبو لإغلاق Hossam State القديم. هذا التحكم مستقل عنه.
