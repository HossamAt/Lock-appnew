# Hossam AI — New Control

This build is prepared to use a separate kill-switch/control namespace from the old Hossam State build.

Old build:
- Hossam-State-Control

New build:
- Hossam-AI-Control

Important:
1. Create/publish the new GitHub control repository with the expected kill-switch file.
2. Deploy the new Android build.
3. Only after the new build is confirmed working, disable the old Hossam State control repository.

The new control repository name is a namespace/reference; it must exist before the app can fetch it.
