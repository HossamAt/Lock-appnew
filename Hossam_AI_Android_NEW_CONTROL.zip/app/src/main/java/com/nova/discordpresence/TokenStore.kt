package com.nova.discordpresence

import android.content.Context

object TokenStore {
    private const val PREFS = "discord_presence_auth"
    private lateinit var context: Context
    fun init(ctx: Context) { context = ctx.applicationContext }
    fun save(access: String, refresh: String, expiresIn: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("access", access).putString("refresh", refresh)
            .putLong("savedAt", System.currentTimeMillis())
            .putInt("expiresIn", expiresIn).apply()
    }
    fun refreshToken(): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("refresh", null)
}
