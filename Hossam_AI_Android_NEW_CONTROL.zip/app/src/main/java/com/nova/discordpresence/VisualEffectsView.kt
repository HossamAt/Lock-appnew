package com.nova.discordpresence

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.sin

/** Subtle ambient shapes behind the UI. Intentionally low-contrast so text stays clear. */
class VisualEffectsView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var phase = 0f

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isClickable = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Large soft circles.
        paint.style = Paint.Style.FILL
        paint.color = 0x16C7A27D
        canvas.drawCircle(w * 0.08f, h * 0.18f, w * 0.30f, paint)
        paint.color = 0x102F6B8F
        canvas.drawCircle(w * 0.93f, h * 0.62f, w * 0.34f, paint)

        // Fine diagonal architectural lines.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = 0x1B9BA9B5
        path.reset()
        path.moveTo(-w * 0.15f, h * 0.32f)
        path.lineTo(w * 0.46f, -h * 0.03f)
        path.lineTo(w * 1.12f, h * 0.28f)
        canvas.drawPath(path, paint)

        path.reset()
        path.moveTo(-w * 0.08f, h * 0.78f)
        path.lineTo(w * 0.52f, h * 1.02f)
        path.lineTo(w * 1.08f, h * 0.72f)
        canvas.drawPath(path, paint)

        // Small moving accent dots, barely visible.
        paint.style = Paint.Style.FILL
        paint.color = 0x3CC7A27D
        val drift = (sin(phase.toDouble()) * 7f).toFloat()
        for (i in 0..5) {
            val x = w * (0.10f + i * 0.17f) + drift
            val y = h * (0.10f + (i % 3) * 0.31f)
            canvas.drawCircle(x, y, 2.1f, paint)
        }

        phase += 0.018f
        if (!isInEditMode) postInvalidateDelayed(45L)
    }
}
