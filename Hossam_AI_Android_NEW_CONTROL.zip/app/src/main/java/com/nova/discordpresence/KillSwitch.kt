package com.nova.discordpresence

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Remote master switch for Hossam State.
 *
 * The app fails open when the control server cannot be reached. This prevents a
 * temporary GitHub/network outage from disabling legitimate users.
 */
object KillSwitch {
    // The GitHub Actions build injects the repository URL automatically.
    // Local builds use a harmless placeholder until built inside the repository.
    val CONTROL_URL: String = "https://raw.githubusercontent.com/HossamAt/Hossam-AI-Control/main/kill_switch.json"

    data class State(
        val enabled: Boolean,
        val message: String
    )

    private val executor = Executors.newSingleThreadExecutor()

    fun checkAsync(context: Context, callback: (State) -> Unit) {
        executor.execute {
            val state = fetch()
            try {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    context.getSharedPreferences("presence_service", Context.MODE_PRIVATE)
                        .edit()
                        .putBoolean("remote_disabled", !state.enabled)
                        .putString("remote_disable_message", state.message)
                        .apply()
                    callback(state)
                }
            } catch (_: Throwable) {
                // Do not crash the app if the UI has already gone away.
            }
        }
    }

    fun fetch(): State {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(CONTROL_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 7_000
                readTimeout = 7_000
                useCaches = false
                setRequestProperty("Cache-Control", "no-cache")
            }

            if (connection.responseCode !in 200..299) {
                // Fail open on server/network problems.
                return State(true, "")
            }

            val body = BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { reader ->
                buildString {
                    reader.forEachLine { append(it) }
                }
            }

            val enabledMatch = Regex("\\\"enabled\\\"\\s*:\\s*(true|false)", RegexOption.IGNORE_CASE).find(body)
            val messageMatch = Regex("\\\"message\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"").find(body)
            val enabled = enabledMatch?.groupValues?.getOrNull(1)?.equals("true", ignoreCase = true) ?: true
            val message = messageMatch?.groupValues?.getOrNull(1)?.trim().orEmpty()
            State(enabled, message)
        } catch (_: Throwable) {
            // Never brick the app because the control endpoint is unavailable.
            State(true, "")
        } finally {
            connection?.disconnect()
        }
    }
}
