package com.nova.discordpresence

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import coil.load
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import org.json.JSONArray
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    companion object {
        var lastStatus: String = "جاهز"
        private const val APP_ID = 1549333944686612570L
        private const val DISCORD_URL = "https://discord.gg/DK4ZRHB4g"
        private const val PREFS = "presence_service"
    }

    enum class Region(val title: String, val subtitle: String) {
        ME("الشرق الأوسط", "Middle East"),
        NAF("شمال أفريقيا", "North Africa")
    }

    data class Server(val name: String, val imageUrl: String)

    private val meServers = listOf(
        Server("Alameda ME", "https://cdn.discordapp.com/emojis/1346557146409472070.png"),
        Server("Barry ME", "https://cdn.discordapp.com/emojis/1412049991991820358.png"),
        Server("Bell ME", "https://cdn.discordapp.com/emojis/1341057206140801085.png"),
        Server("Chico ME", "https://cdn.discordapp.com/emojis/1341057490258886721.png"),
        Server("Covina ME", "https://cdn.discordapp.com/emojis/1341057310981619784.png"),
        Server("Forest ME", "https://cdn.discordapp.com/emojis/1389265233553522778.png"),
        Server("Fortuna ME", "https://cdn.discordapp.com/emojis/1364572804250472448.png"),
        Server("Glendale ME", "https://f.top4top.io/p_3910rgmcv0.png"),
        Server("Hemet ME", "https://cdn.discordapp.com/emojis/1412049963973738596.png"),
        Server("Hills ME", "https://cdn.discordapp.com/emojis/1341057349087002735.png"),
        Server("Homeland ME", "https://cdn.discordapp.com/emojis/1343966484333989970.png"),
        Server("Laguna ME", "https://cdn.discordapp.com/emojis/1341057622941634671.png"),
        Server("Lincoln ME", "https://cdn.discordapp.com/emojis/1356278039570415867.png"),
        Server("Lomita ME", "https://cdn.discordapp.com/emojis/1341057167804858369.png"),
        Server("Lynwood ME", "https://cdn.discordapp.com/emojis/1341057244707422308.png"),
        Server("Madera ME", "https://cdn.discordapp.com/emojis/1350846504079855647.png"),
        Server("Malibu ME", "https://cdn.discordapp.com/emojis/1487960389982486648.png"),
        Server("Mesa ME", "https://cdn.discordapp.com/emojis/1341057580209799260.png"),
        Server("Napa ME", "https://cdn.discordapp.com/emojis/1341057528842289235.png"),
        Server("Orange ME", "https://b.top4top.io/p_3910rj4y80.png"),
        Server("Redland ME", "https://d.top4top.io/p_39104dukk0.png"),
        Server("Solano ME", "https://k.top4top.io/p_39104u11a0.png"),
        Server("Wasco ME", "https://e.top4top.io/p_3910qazz50.png"),
        Server("Yuba ME", "https://g.top4top.io/p_3910scuj90.png"),
        Server("Santa Cruz ME", "https://h.top4top.io/p_39126wu7x0.png")
    )

    private val nafServers = listOf(
        Server("Chico NAF", "https://cdn.discordapp.com/emojis/1341057490258886721.png"),
        Server("Bell NAF", "https://cdn.discordapp.com/emojis/1341057206140801085.png"),
        Server("Lynwood NAF", "https://cdn.discordapp.com/emojis/1341057244707422308.png"),
        Server("Glendale NAF", "https://f.top4top.io/p_3910rgmcv0.png"),
        Server("Covina NAF", "https://cdn.discordapp.com/emojis/1341057310981619784.png"),
        Server("Hills NAF", "https://cdn.discordapp.com/emojis/1341057349087002735.png")
    )

    private var region: Region? = null
    private var selectedServer: Server? = null
    private var connected = false
    private lateinit var content: LinearLayout
    private lateinit var connectionLabel: TextView
    private lateinit var timerText: TextView
    private lateinit var toggle: PresenceToggle
    private val timerHandler = Handler(Looper.getMainLooper())
    private val timerRunnable = object : Runnable {
        override fun run() {
            updateTimer()
            timerHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        buildShell()
        syncRunningPresence()
        timerHandler.post(timerRunnable)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bodyFont(bold: Boolean = false): Typeface =
        Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)

    private fun txt(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        includeFontPadding = false
        typeface = bodyFont(false)
        letterSpacing = if (size >= 16f) 0.015f else 0.005f
    }

    private fun addSpace(p: LinearLayout, h: Int) {
        p.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    private fun buildShell() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(28, 34, 48)) }
        val bg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.44f
            load(R.drawable.app_background)
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(182, 24, 31, 45))
        }, FrameLayout.LayoutParams(-1, -1))

        // Subtle visual atmosphere: translucent circles + diagonal accents.
        root.addView(VisualEffectsView(this), FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            setPadding(dp(16), dp(22), dp(16), dp(28))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showHome()
    }

    private fun header(title: String, subtitle: String? = null, back: Boolean = false) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        if (back) {
            val b = txt("‹", 34f, Color.rgb(224, 194, 160)).apply {
                gravity = Gravity.CENTER
                setOnClickListener { showHome() }
                typeface = bodyFont(true)
            }
            row.addView(b, LinearLayout.LayoutParams(dp(44), dp(48)))
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (back) Gravity.CENTER else Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        texts.addView(txt(title, 28f, Color.rgb(243, 241, 238)).apply {
            typeface = bodyFont(true)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(34)))
        subtitle?.let {
            texts.addView(txt(it, 12f, Color.rgb(180, 190, 197)).apply {
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, dp(22)))
        }
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        if (back) row.addView(View(this), LinearLayout.LayoutParams(dp(44), dp(48)))
        content.addView(row, LinearLayout.LayoutParams(-1, -2))
        addSpace(content, 14)
    }

    private fun showHome() {
        region = null
        content.removeAllViews()
        header("Hossam State", "OneState • Discord Rich Presence")

        addHomeCard("الشرق الأوسط", "Middle East", "25 سيرفر متاح", false) { openRegion(Region.ME) }
        addSpace(content, 12)
        addHomeCard("شمال أفريقيا", "North Africa", "6 سيرفرات متاحة", false) { openRegion(Region.NAF) }
        addSpace(content, 12)
        addHomeCard("مجتمع الديسكورد", "Discord Community", "انضم إلى المجتمع", true) { openDiscord() }
        addSpace(content, 12)
        addHomeCard("Hossam AI", "OneState Rules Assistant", "مساعدك الذكي لقوانين OneState فقط", false) { showAiChat() }
        addSpace(content, 26)

        val status = txt(
            if (connected) "●  متصل حاليًا" else "●  جاهز للاتصال",
            12f,
            if (connected) Color.rgb(87, 211, 138) else Color.rgb(180, 190, 197)
        ).apply { gravity = Gravity.CENTER }
        content.addView(status, LinearLayout.LayoutParams(-1, dp(26)))
        addSpace(content, 10)
        content.addView(txt("HOSSAM STATE  •  2.0", 10f, Color.rgb(143, 158, 165)).apply {
            gravity = Gravity.CENTER
            typeface = bodyFont(true)
        }, LinearLayout.LayoutParams(-1, dp(22)))
        animateContentIn()
    }

    private fun addHomeCard(title: String, sub: String, detail: String, discord: Boolean, click: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundResource(R.drawable.bg_glass)
            isClickable = true
            setOnClickListener { click() }
        }
        val icon = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(4), dp(4), dp(4), dp(4))
            if (discord) load(R.drawable.discord_icon)
        }
        if (!discord) {
            icon.setImageResource(android.R.drawable.ic_menu_compass)
            icon.setColorFilter(Color.rgb(224, 194, 160))
        }
        card.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), 0, dp(10), 0)
        }
        texts.addView(txt(title, 17f, Color.rgb(243, 241, 238)).apply {
            typeface = bodyFont(true)
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, dp(27)))
        texts.addView(txt(sub, 10f, Color.rgb(143, 158, 165)).apply { gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, dp(19)))
        texts.addView(txt(detail, 11f, Color.rgb(199, 162, 125)).apply { gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, dp(20)))
        card.addView(texts, LinearLayout.LayoutParams(0, -1, 1f))
        card.addView(txt("‹", 30f, Color.rgb(199, 162, 125)).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(32), dp(54)))
        content.addView(card, LinearLayout.LayoutParams(-1, dp(92)))
    }


    // Set this to your deployed HTTPS backend endpoint. Keep provider API keys on the server only.
    private val aiBackendUrl = "https://hossam-ai-backend.hossamataya2001.workers.dev/chat"

    private data class AiTurn(
        val user: String,
        var assistant: String = ""
    )

    private val aiConversation = mutableListOf<AiTurn>()

    private fun showAiChat() {
        content.removeAllViews()
        header("Hossam AI", "مساعدك الذكي لقوانين OneState فقط", true)

        val intro = txt(
            "اسأل عن الحالة، وإذا كانت معلومة مهمة ناقصة رح أسألك عنها باختصار.",
            14f,
            Color.rgb(225, 228, 232)
        ).apply {
            gravity = Gravity.RIGHT
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundResource(R.drawable.bg_glass)
        }
        content.addView(intro, LinearLayout.LayoutParams(-1, -2))
        addSpace(content, 12)

        val transcript = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        content.addView(transcript, LinearLayout.LayoutParams(-1, -2))

        if (aiConversation.isNotEmpty()) {
            aiConversation.forEach { turn ->
                appendAiMessage(transcript, turn.user, true)
                if (turn.assistant.isNotBlank()) {
                    appendAiMessage(transcript, turn.assistant, false)
                }
            }
        }

        val input = EditText(this).apply {
            hint = "اكتب الحالة أو أكمل التفاصيل..."
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(143, 158, 165))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_glass)
            minLines = 1
            maxLines = 4
        }
        content.addView(input, LinearLayout.LayoutParams(-1, -2))
        addSpace(content, 10)

        val send = Button(this).apply {
            text = "إرسال"
            setOnClickListener {
                val question = input.text?.toString()?.trim().orEmpty()
                if (question.isBlank()) {
                    input.error = "اكتب سؤالك أولاً"
                    return@setOnClickListener
                }

                val turn = AiTurn(question)
                aiConversation.add(turn)

                appendAiMessage(transcript, question, true)
                input.setText("")

                val loading = appendAiMessage(transcript, "أفكر بالحالة...", false)

                requestAiAnswer(question) { answer ->
                    runOnUiThread {
                        transcript.removeView(loading)
                        turn.assistant = answer
                        appendAiMessage(transcript, answer, false)
                    }
                }
            }
        }
        content.addView(send, LinearLayout.LayoutParams(-1, dp(50)))

        addSpace(content, 8)
        content.addView(
            txt(
                "Hossam AI • OneState Rules",
                11f,
                Color.rgb(143, 158, 165)
            ).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, -2)
        )

        animateContentIn()
    }

    private fun styledAiText(message: String, user: Boolean): CharSequence {
        val text = message.removePrefix("Hossam AI:").trim()
        val out = SpannableStringBuilder(text)

        fun colorRegex(pattern: Regex, color: Int, bold: Boolean = true) {
            pattern.findAll(text).forEach { match ->
                out.setSpan(
                    ForegroundColorSpan(color),
                    match.range.first,
                    match.range.last + 1,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                if (bold) {
                    out.setSpan(
                        StyleSpan(Typeface.BOLD),
                        match.range.first,
                        match.range.last + 1,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
        }

        if (user) {
            colorRegex(Regex(".*"), Color.rgb(243, 241, 238), false)
        } else {
            colorRegex(
                Regex("⚖️|🔎|📋|📍|⛓️|🚨|❓|⚠️|🟢|🔴|🟡|⚪"),
                Color.rgb(199, 162, 125),
                true
            )
            colorRegex(
                Regex("RP\\d+(?:\\.\\d+)?|CHAT\\d+(?:\\.\\d+)?|TCHAT\\d+(?:\\.\\d+)?|ABUSE\\d+(?:\\.\\d+)?|ALERT\\d+(?:\\.\\d+)?|MEDIA\\d+(?:\\.\\d+)?|CLAN\\d+(?:\\.\\d+)?|MD\\d+(?:\\.\\d+)?|NAME\\d+(?:\\.\\d+)?|AC\\d+(?:\\.\\d+)?"),
                Color.rgb(199, 162, 125),
                true
            )
            colorRegex(
                Regex("\\b\\d+\\s*(?:دقيقة|دقائق|ساعة|ساعات|يوم|أيام)\\b"),
                Color.rgb(240, 105, 105),
                true
            )
            colorRegex(
                Regex("خضراء|آمنة|تم تحديد|واضح|واضحة|صحيح"),
                Color.rgb(87, 211, 138),
                true
            )
            colorRegex(
                Regex("حمراء|عقوبة|مخالفة|غير مسموح|تحذير|حظر|سجن"),
                Color.rgb(235, 105, 105),
                true
            )
        }

        return out
    }

    private fun appendAiMessage(
        parent: LinearLayout,
        message: String,
        user: Boolean
    ): View {
        val bubble = TextView(this).apply {
            text = styledAiText(message, user)
            textSize = if (user) 14f else 14.5f
            setTextColor(Color.rgb(243, 241, 238))
            gravity = Gravity.RIGHT
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setBackgroundResource(
                if (user) R.drawable.bg_glass_selected else R.drawable.bg_glass
            )
        }

        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(8)
        parent.addView(bubble, lp)
        return bubble
    }

    private fun requestAiAnswer(
        question: String,
        callback: (String) -> Unit
    ) {
        if (aiBackendUrl.contains("YOUR-BACKEND-DOMAIN")) {
            callback("الخدمة غير مفعلة حالياً.")
            return
        }

        thread {
            var result = "تعذر الاتصال بالخدمة."
            var conn: HttpURLConnection? = null

            try {
                conn = (URL(aiBackendUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty(
                        "Content-Type",
                        "application/json; charset=utf-8"
                    )
                }

                val history = JSONArray()
                aiConversation.takeLast(8).forEach { turn ->
                    history.put(
                        JSONObject()
                            .put("user", turn.user)
                            .put("assistant", turn.assistant)
                    )
                }

                val payload = JSONObject()
                    .put("message", question)
                    .put("history", history)
                    .toString()

                conn.outputStream.use {
                    it.write(payload.toByteArray(Charsets.UTF_8))
                }

                val stream =
                    if (conn.responseCode in 200..299)
                        conn.inputStream
                    else
                        conn.errorStream

                val body = stream
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use { it.readText() }
                    .orEmpty()
                    .trim()

                if (body.isBlank()) {
                    result = "تعذر الحصول على رد."
                } else {
                    try {
                        val json = JSONObject(body)
                        result = when {
                            json.optString("answer").isNotBlank() ->
                                json.optString("answer").trim()

                            json.optString("reply").isNotBlank() ->
                                json.optString("reply").trim()

                            else ->
                                "تعذر فهم الرد."
                        }
                    } catch (_: Exception) {
                        result =
                            if (body.length <= 4000) body
                            else "تعذر فهم الرد."
                    }
                }

            } catch (_: Exception) {
                result = "تعذر الاتصال بالخدمة. تأكد من الإنترنت."
            } finally {
                conn?.disconnect()
            }

            callback(result)
        }
    }

    private fun openDiscord() {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL)).apply { setPackage("com.discord") }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL)))
        }
    }

    private fun openRegion(r: Region) {
        region = r
        val list = if (r == Region.ME) meServers else nafServers
        if (selectedServer == null || !list.contains(selectedServer)) selectedServer = list.firstOrNull()
        buildRegionPage()
    }

    private fun buildRegionPage() {
        val r = region ?: return
        val servers = if (r == Region.ME) meServers else nafServers
        content.removeAllViews()
        header(r.title, r.subtitle, true)

        val selected = selectedServer
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundResource(R.drawable.bg_glass_selected)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            load(selected?.imageUrl ?: "")
        }
        top.addView(img, LinearLayout.LayoutParams(dp(56), dp(56)))
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), 0, dp(10), 0)
        }
        names.addView(txt(selected?.name ?: "—", 17f, Color.rgb(243, 241, 238)).apply {
            typeface = bodyFont(true)
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, dp(27), 1f))
        names.addView(txt("السيرفر المحدد", 10f, Color.rgb(143, 158, 165)).apply {
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, dp(20)))
        top.addView(names, LinearLayout.LayoutParams(0, dp(56), 1f))
        hero.addView(top)
        addSpace(hero, 14)

        val statusRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        connectionLabel = txt(
            if (connected) "متصل" else "غير متصل",
            13f,
            if (connected) Color.rgb(87, 211, 138) else Color.rgb(180, 190, 197)
        ).apply { gravity = Gravity.CENTER_VERTICAL }
        statusRow.addView(connectionLabel, LinearLayout.LayoutParams(0, dp(34), 1f))

        timerText = txt("00:00:00", 18f, Color.rgb(243, 241, 238)).apply {
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-mono", Typeface.BOLD)
            letterSpacing = 0.02f
        }
        statusRow.addView(timerText, LinearLayout.LayoutParams(dp(120), dp(34)))

        toggle = PresenceToggle(this)
        toggle.setChecked(connected, false)
        toggle.onCheckedChange = { checked ->
            if (checked) startSelectedPresence() else stopRunningPresence()
        }
        statusRow.addView(toggle, LinearLayout.LayoutParams(dp(70), dp(40)))
        hero.addView(statusRow)
        content.addView(hero, LinearLayout.LayoutParams(-1, -2))

        addSpace(content, 18)
        content.addView(txt("السيرفرات", 18f, Color.rgb(243, 241, 238)).apply {
            typeface = bodyFont(true)
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, dp(28)))
        addSpace(content, 8)
        servers.forEach { addServerRow(it) }
        addSpace(content, 12)
        content.addView(txt("اسحب المفتاح لليمين للاتصال", 10f, Color.rgb(143, 158, 165)).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(24)))
        animateContentIn()
    }

    private fun addServerRow(server: Server) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundResource(if (server.name == selectedServer?.name) R.drawable.bg_server_selected else R.drawable.bg_server)
            setOnClickListener { selectServer(server) }
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            load(server.imageUrl)
        }
        row.addView(img, LinearLayout.LayoutParams(dp(48), dp(48)))
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), 0, dp(8), 0)
        }
        names.addView(txt(server.name, 14f, Color.rgb(243, 241, 238)).apply {
            typeface = bodyFont(true)
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, dp(24)))
        names.addView(txt("OneState", 10f, Color.rgb(143, 158, 165)).apply { gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, dp(18)))
        row.addView(names, LinearLayout.LayoutParams(0, dp(52), 1f))
        val dot = txt(
            if (connected && server.name == selectedServer?.name) "●" else "○",
            14f,
            if (connected && server.name == selectedServer?.name) Color.rgb(87, 211, 138) else Color.rgb(143, 158, 165)
        ).apply { gravity = Gravity.CENTER }
        row.addView(dot, LinearLayout.LayoutParams(dp(28), dp(52)))
        content.addView(row, LinearLayout.LayoutParams(-1, dp(68)).apply { bottomMargin = dp(7) })
    }

    private fun selectServer(server: Server) {
        val wasConnected = connected
        val oldServer = selectedServer
        selectedServer = server
        if (wasConnected && oldServer?.name != server.name) updateRunningPresence() else buildRegionPage()
    }

    private fun startSelectedPresence() {
        val server = selectedServer ?: return

        if (::connectionLabel.isInitialized) {
            connectionLabel.text = "جاري التحقق..."
            connectionLabel.setTextColor(Color.rgb(199, 162, 125))
        }

        KillSwitch.checkAsync(this) { remote ->
            if (!remote.enabled) {
                connected = false
                if (::connectionLabel.isInitialized) {
                    connectionLabel.text = "التطبيق متوقف"
                    connectionLabel.setTextColor(Color.rgb(231, 123, 123))
                }
                if (::toggle.isInitialized) toggle.setChecked(false, true)
                android.widget.Toast.makeText(
                    this,
                    remote.message.ifBlank { "تم إيقاف Hossam State مؤقتًا من قبل المطور." },
                    android.widget.Toast.LENGTH_LONG
                ).show()
                return@checkAsync
            }

            startSelectedPresenceAfterCheck(server)
        }
    }

    private fun startSelectedPresenceAfterCheck(server: Server) {
        try {
            val p = getSharedPreferences(PREFS, MODE_PRIVATE)
            val now = System.currentTimeMillis() / 1000L
            val savedActive = p.getBoolean("active", false)
            val savedServer = p.getString("largeText", null)
            val savedEpoch = p.getLong("startEpoch", 0L)
            val pausedElapsed = p.getLong("pausedElapsed::${server.name}", -1L)
            val legacyPausedServer = p.getString("pausedServer", null)
            val legacyPausedElapsed = p.getLong("pausedElapsed", 0L).coerceAtLeast(0L)

            // Reconnect to the same server: restore its exact saved elapsed time.
            val startEpoch = when {
                savedActive && savedServer == server.name && savedEpoch > 0L -> savedEpoch
                pausedElapsed >= 0L -> now - pausedElapsed
                legacyPausedServer == server.name -> now - legacyPausedElapsed
                else -> now
            }

            val config = PresenceService.Config(
                "OneState",
                "Server : ${server.name}",
                "by Hossamat",
                server.imageUrl,
                server.name,
                "",
                "",
                startEpoch
            )
            PresenceService.currentConfig = config
            startServiceWithConfig(config, forceReset = false)
            connected = true
            connectionLabel.text = "متصل"
            connectionLabel.setTextColor(Color.rgb(87, 211, 138))
            toggle.setChecked(true, true)
            buildRegionPage()
        } catch (_: Throwable) {
            connected = false
            if (::connectionLabel.isInitialized) {
                connectionLabel.text = "فشل الاتصال"
                connectionLabel.setTextColor(Color.rgb(231, 123, 123))
            }
            if (::toggle.isInitialized) toggle.setChecked(false, true)
        }
    }

    private fun updateRunningPresence() {
        val server = selectedServer ?: return
        val old = PresenceService.currentConfig
        val oldServer = old?.largeText
        val epoch = if (old != null && oldServer == server.name) old.startEpoch else System.currentTimeMillis() / 1000L
        val config = PresenceService.Config(
            "OneState",
            "Server : ${server.name}",
            "by Hossamat",
            server.imageUrl,
            server.name,
            "",
            "",
            epoch
        )
        PresenceService.currentConfig = config
        startServiceWithConfig(config, forceReset = false)
        connected = true
        buildRegionPage()
    }

    private fun stopRunningPresence() {
        connected = false

        // Save the paused timer synchronously BEFORE clearing the service config.
        // The previous version set PresenceService.currentConfig = null first,
        // so ACTION_STOP could arrive with no config and nothing was saved.
        val config = PresenceService.currentConfig
        if (config != null) {
            val now = System.currentTimeMillis() / 1000L
            val elapsed = (now - config.startEpoch).coerceAtLeast(0L)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("active", false)
                .putString("pausedServer", config.largeText)
                .putLong("pausedElapsed", elapsed)
                .putLong("pausedElapsed::${config.largeText}", elapsed)
                .commit()
        } else {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("active", false)
                .commit()
        }

        // Let the foreground service clear Discord Rich Presence and finish
        // its shutdown cleanly. It will also persist the same timer snapshot.
        startService(Intent(this, PresenceService::class.java).apply { action = PresenceService.ACTION_STOP })
        PresenceService.currentConfig = null

        if (region != null) buildRegionPage() else showHome()
    }

    private fun startServiceWithConfig(c: PresenceService.Config, forceReset: Boolean) {
        val intent = Intent(this, PresenceService::class.java).apply {
            action = PresenceService.ACTION_UPDATE
            putExtra("name", c.name)
            putExtra("details", c.details)
            putExtra("state", c.state)
            putExtra("largeImage", c.largeImage)
            putExtra("largeText", c.largeText)
            putExtra("smallImage", c.smallImage)
            putExtra("smallText", c.smallText)
            putExtra("startEpoch", c.startEpoch)
            putExtra("forceReset", forceReset)
        }
        androidx.core.content.ContextCompat.startForegroundService(this, intent)
    }

    private fun syncRunningPresence() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!p.getBoolean("active", false)) {
            connected = false
            return
        }

        KillSwitch.checkAsync(this) { remote ->
            if (!remote.enabled) {
                connected = false
                p.edit().putBoolean("active", false).apply()
                if (::toggle.isInitialized) toggle.setChecked(false, false)
                if (::connectionLabel.isInitialized) {
                    connectionLabel.text = "التطبيق متوقف"
                    connectionLabel.setTextColor(Color.rgb(231, 123, 123))
                }
                startService(Intent(this, PresenceService::class.java).apply {
                    action = PresenceService.ACTION_STOP
                })
                return@checkAsync
            }

            val active = PresenceService.currentConfig ?: PresenceService.Config(
                p.getString("name", "OneState") ?: "OneState",
                p.getString("details", "Server : Fortuna ME") ?: "Server : Fortuna ME",
                p.getString("state", "by Hossamat") ?: "by Hossamat",
                p.getString("largeImage", "") ?: "",
                p.getString("largeText", "") ?: "",
                p.getString("smallImage", "") ?: "",
                p.getString("smallText", "") ?: "",
                p.getLong("startEpoch", System.currentTimeMillis() / 1000L)
            )
            PresenceService.currentConfig = active
            connected = true
            val name = active.details.removePrefix("Server : ")
            if (meServers.any { it.name == name }) {
                region = Region.ME
                selectedServer = meServers.first { it.name == name }
            } else if (nafServers.any { it.name == name }) {
                region = Region.NAF
                selectedServer = nafServers.first { it.name == name }
            }
            if (region != null) buildRegionPage()
            startServiceWithConfig(active, false)
        }
    }

    private fun updateTimer() {
        if (!::timerText.isInitialized) return

        val seconds = if (connected) {
            val epoch = PresenceService.currentConfig?.startEpoch ?: return
            ((System.currentTimeMillis() / 1000L) - epoch).coerceAtLeast(0L)
        } else {
            val p = getSharedPreferences(PREFS, MODE_PRIVATE)
            val selectedName = selectedServer?.name
            if (selectedName != null) {
                val perServer = p.getLong("pausedElapsed::$selectedName", -1L)
                if (perServer >= 0L) {
                    perServer
                } else if (p.getString("pausedServer", null) == selectedName) {
                    p.getLong("pausedElapsed", 0L).coerceAtLeast(0L)
                } else {
                    0L
                }
            } else {
                0L
            }
        }

        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        timerText.text = String.format("%02d:%02d:%02d", h, m, s)
    }

    private fun animateContentIn() {
        content.alpha = 0f
        content.translationY = dp(8).toFloat()
        content.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(260L)
            .start()
    }

    override fun onBackPressed() {
        if (region != null) {
            region = null
            showHome()
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        timerHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
