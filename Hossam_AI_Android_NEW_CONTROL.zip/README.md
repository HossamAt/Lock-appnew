# Hossam State 2.0

OneState Discord Rich Presence app combining Middle East (ME) and North Africa (NAF) servers.

- Main menu: Middle East / North Africa / Discord Community
- Persistent Rich Presence with auto-reconnect
- Custom starting timer: hours / minutes / seconds
- Drag-style connection switch
- Game-image background with dark blue overlay
- Discord community shortcut

Build with the included GitHub Actions workflow.

## Central Kill Switch
The project includes `kill_switch.json`, the `Hossam State Kill Switch` GitHub Actions workflow, and a simple `control-panel` UI. See `CONTROL_PANEL_GUIDE.md` for setup.


## Control server
The app is connected to `HossamAt/Hossam-AI-Control` for the remote Kill Switch.
