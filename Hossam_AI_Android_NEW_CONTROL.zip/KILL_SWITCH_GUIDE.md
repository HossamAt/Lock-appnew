# Hossam State — Kill Switch

## What it does

The Android app checks `kill_switch.json` remotely. If `enabled` is `false`, the app:

- stops new Rich Presence connections;
- clears the current Discord Rich Presence;
- stops the foreground presence service;
- shows the configured Arabic message when the user tries to reconnect.

The service checks approximately every 30 seconds while a presence is active.

## Important

The app is built to **fail open** if GitHub or the internet is temporarily unreachable. A network outage therefore does not disable users by accident.

Only app builds that contain this Kill Switch code can be remotely controlled. Older APKs from before this feature was added cannot be stopped remotely.

## One-click control

The included GitHub Actions workflow is:

`Actions` → `Hossam State Kill Switch` → `Run workflow`

Choose:

- `true` = enable the app
- `false` = disable the app for supported installed versions

You can also edit `kill_switch.json` directly:

```json
{
  "enabled": false,
  "message": "تم إيقاف Hossam State مؤقتًا من قبل المطور."
}
```

The Android GitHub build automatically embeds the current repository's raw `kill_switch.json` URL, so you do not need to manually type the repository name into Kotlin code.

## Repository requirement

The GitHub repository must be public because the Android app reads the raw JSON without authentication.
